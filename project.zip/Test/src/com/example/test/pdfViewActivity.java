package com.example.test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.RandomAccessFile;

import net.sf.andpdf.nio.ByteBuffer;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.ViewTreeObserver;
import android.webkit.WebView;

import com.sun.pdfview.PDFFile;
import com.sun.pdfview.PDFPage;


public class pdfViewActivity extends Activity{
	String pdfFile;
	WebView pdfView;
	File pdf;
	int ViewSize = 0;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pdfview);
        pdfView = (WebView)findViewById(R.id.pdfView1);
        pdfView.getSettings().setBuiltInZoomControls(true);
        pdfView.getSettings().setSupportZoom(true);
        pdfView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(){
			@Override
			public void onGlobalLayout() {
				ViewSize = pdfView.getWidth();
				pdfView.getViewTreeObserver().removeGlobalOnLayoutListener(this);				
			}
		});     
    }
    
    @Override
    protected void onResume(){
    	super.onResume();
    	try{
    		Intent intent = getIntent();
    		pdfFile = intent.getExtras().getString("pdfFile");
    		pdf = new File(pdfFile);    		
        	RandomAccessFile f = new RandomAccessFile(pdf, "r");
        	byte[] data = new byte[(int)f.length()];
        	f.readFully(data);
        	pdfLoadImage(data);
        	Log.i("pdf", pdfFile);
    	}catch(Exception e){
    		Log.i("pdf", "fail");
    	}
    }
    
    private void pdfLoadImage(final byte[] data){
    	try{
    		new AsyncTask<Void, Void, String>(){
    			 ProgressDialog progressDialog = ProgressDialog.show(pdfViewActivity.this, "", "Opening...");
    			@Override
    			protected void onPostExecute(String html){
    				progressDialog.dismiss();
    				pdfView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", "");
    			}
				@Override
				protected String doInBackground(Void... params) {
					try{
						ByteBuffer buffer = ByteBuffer.NEW(data);
						PDFFile pdf = new PDFFile(buffer);
						PDFPage PDFpage = pdf.getPage(1, true);
						final float scale = ViewSize / PDFpage.getWidth();
						Bitmap page = PDFpage.getImage((int)(PDFpage.getWidth() * scale), (int)(PDFpage.getHeight() * scale), null, true, true);
						ByteArrayOutputStream stream = new ByteArrayOutputStream();
						page.compress(Bitmap.CompressFormat.PNG, 100, stream);
						byte[] byteArray = stream.toByteArray();
						stream.reset();
						String base64 = Base64.encodeToString(byteArray, Base64.NO_WRAP);
						String html = "<!DOCTYPE html><html><body bgcolor=\"#b4b4b4\"><img src=\"data:image/png;base64,"+base64+"\" hspace=10 vspace=10><br>";						 
	                    for(int i = 2; i <= pdf.getNumPages(); i++)
	                    {
	                        PDFpage = pdf.getPage(i, true);
	                        page = PDFpage.getImage((int)(PDFpage.getWidth() * scale), (int)(PDFpage.getHeight() * scale), null, true, true);
	                        page.compress(Bitmap.CompressFormat.PNG, 100, stream);
	                        byteArray = stream.toByteArray();
	                        stream.reset();
	                        base64 = Base64.encodeToString(byteArray, Base64.NO_WRAP);
	                        html += "<img src=\"data:image/png;base64,"+base64+"\" hspace=10 vspace=10><br>";
	                    }
	                    stream.close();
	                    html += "</body></html>";
	                    return html;						
					}catch(Exception e){
						Log.d("error", e.toString());
					}
					return null;
				}				
    		}.execute();
    		System.gc();
    	}catch(Exception e){
    		Log.d("error", e.toString());
    	}
    }
}
